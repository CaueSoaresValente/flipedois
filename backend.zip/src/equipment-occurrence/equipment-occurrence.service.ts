import { BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, EntityManager, Repository } from 'typeorm';

import { EquipmentOccurrence } from './equipment-occurrence.entity';
import { Equipment } from '../equipment/equipment.entity';
import { Event } from '../event/event.entity';
import { ChecklistItem } from '../checklist-item/checklist-item.entity';
import { Checklist } from '../checklist/checklist.entity';
import { StockService } from '../stock/stock.service';

@Injectable()
export class EquipmentOccurrenceService {
  constructor(
    @InjectRepository(EquipmentOccurrence)
    private repo: Repository<EquipmentOccurrence>,

    @InjectRepository(Equipment)
    private equipmentRepo: Repository<Equipment>,

    @InjectRepository(Event)
    private eventRepo: Repository<Event>,

    @InjectRepository(ChecklistItem)
    private checklistItemRepo: Repository<ChecklistItem>,

    private readonly dataSource: DataSource,
    private readonly stockService: StockService,
  ) {}

  // ============================================================
  // CHECKLIST AUTO-SYNC — Single source of truth
  // ============================================================
  /**
   * Recalcula os campos OK/Qb/Pd do checklist item a partir das ocorrências.
   * Esta é a ÚNICA forma de atualizar esses campos.
   *
   * Regra:
   *   quantidadeOk = quantidadeDevolvida - (soma de DANO ativas) - (soma de PERDA ativas)
   *   quantidadeQuebrada = soma de DANO ativas
   *   quantidadePerdida = soma de PERDA ativas
   */
  async syncChecklistItemFromOccurrences(
    manager: EntityManager,
    checklistItemId: number,
  ): Promise<void> {
    if (!checklistItemId) return;

    const item = await manager.findOne(ChecklistItem, {
      where: { id: checklistItemId },
      relations: ['checklist'],
    });

    if (!item) return;

    // Find all active occurrences linked to this checklist item
    // Active = NOT CANCELADO
    const occurrences = await manager.find(EquipmentOccurrence, {
      where: { checklistItemId },
    });

    const activeOccurrences = occurrences.filter(
      (o) => o.status !== 'CANCELADO',
    );

    const totalDano = activeOccurrences
      .filter((o) => o.tipo === 'DANO')
      .reduce((sum, o) => sum + o.quantidade, 0);

    const totalPerda = activeOccurrences
      .filter((o) => o.tipo === 'PERDA')
      .reduce((sum, o) => sum + o.quantidade, 0);

    const baseOk = Math.max(0, item.quantidadeDevolvida - totalDano - totalPerda);
    item.quantidadeOk = baseOk;
    item.quantidadeQuebrada = totalDano;
    item.quantidadePerdida = totalPerda;

    // Determine status
    if (item.quantidadeDevolvida === 0) {
      item.statusDevolucao = 'pendente';
    } else if (totalPerda > 0) {
      item.statusDevolucao = 'perdido';
    } else if (totalDano > 0) {
      item.statusDevolucao = 'quebrado';
    } else {
      item.statusDevolucao = 'devolvido';
    }

    // Check if any occurrences are still PENDENTE (awaiting confirmation)
    const hasPending = activeOccurrences.some((o) => o.status === 'PENDENTE');
    if (hasPending && item.quantidadeDevolvida > 0) {
      item.statusDevolucao = 'aguardando_confirmacao';
    }

    await manager.save(ChecklistItem, item);

    // Also update the parent checklist status
    await this.atualizarStatusChecklistTx(manager, item.checklistId);
  }

  /**
   * Atualiza status automático do checklist baseado nos itens.
   */
  private async atualizarStatusChecklistTx(
    manager: EntityManager,
    checklistId: number,
  ) {
    const checklist = await manager.findOne(Checklist, {
      where: { id: checklistId },
      relations: ['items'],
    });

    if (!checklist || !checklist.items.length) return;

    const items = checklist.items;

    const todosSeparados = items.every(
      (i: ChecklistItem) => i.quantidadeSeparada === i.quantidadePlanejada,
    );

    const algumDevolvido = items.some(
      (i: ChecklistItem) => i.quantidadeDevolvida > 0,
    );

    const todosFinalizados = items.every(
      (i: ChecklistItem) =>
        i.quantidadeSeparada > 0 &&
        ['devolvido', 'quebrado', 'perdido'].includes(i.statusDevolucao),
    );

    const algumAguardando = items.some(
      (i: ChecklistItem) => i.statusDevolucao === 'aguardando_confirmacao',
    );

    if (todosFinalizados) {
      checklist.status = 'concluido';
    } else if (algumAguardando || algumDevolvido) {
      checklist.status = 'pendente_devolucao';
    } else if (todosSeparados) {
      checklist.status = 'em_evento';
    } else {
      checklist.status = 'liberado';
    }

    await manager.save(Checklist, checklist);
  }

  // ============================================================
  // STOCK REVERSAL HELPER
  // ============================================================
  /**
   * Reverte o impacto no estoque de uma ocorrência.
   *
   * BAIXADO: estoque foi alterado na confirmação → reverter
   * PENDENTE manual: estoque foi alterado na criação → reverter
   * PENDENTE de devolução: itens ainda em emUso → retornar para disponivel
   */
  private async reverterImpactoEstoque(
    manager: EntityManager,
    occurrence: EquipmentOccurrence,
  ) {
    const { tipo, quantidade, equipment, status } = occurrence;

    if (status === 'BAIXADO') {
      // BAIXADO: estoque foi alterado na confirmação → reverter
      if (tipo === 'DANO') {
        await this.stockService.cancelarDano(manager, equipment.id, quantidade);
      } else if (tipo === 'PERDA') {
        await this.stockService.cancelarPerda(manager, equipment.id, quantidade);
      } else if (tipo === 'OK') {
        // OK BAIXADO: emUso -= qty, disponivel += qty -> reverter: emUso += qty, disponivel -= qty
        await this.stockService.reservarEstoque(
          manager,
          equipment.id,
          quantidade,
        );
      }
    }
    // Se status é PENDENTE: estoque NÃO foi alterado ainda (modelo "Confirm Always")
  }

  // aplicarImpactoEstoque removido: impacto agora só em confirmarBaixa()

  // ============================================================
  // REGISTRAR (create occurrence)
  // ============================================================
  /**
   * Registra uma ocorrência de dano, perda ou ok.
   *
   * Para DANO e PERDA gerados via devolução de checklist (manual = false):
   *   NÍO altera estoque. Estoque só muda via confirmarBaixa().
   *
   * Para DANO e PERDA manuais (manual = true):
   *   NÍO altera estoque na criação. Estoque só muda via confirmarBaixa().
   */
  async registrar(
    eventId: number | null,
    equipmentId: number,
    quantidade: number,
    descricao?: string,
    tipo: 'OK' | 'DANO' | 'PERDA' = 'DANO',
    manual: boolean = false,
    checklistItemId?: number | null,
  ) {
    return this.dataSource.transaction(async (manager) => {
      const equipment = await manager.findOne(Equipment, {
        where: { id: equipmentId },
      });

      if (!equipment)
        throw new BadRequestException('Equipamento não encontrado.');

      let event: Event | null = null;
      if (eventId) {
        event = await manager.findOne(Event, { where: { id: eventId } });
        if (!event) throw new BadRequestException('Evento não encontrado.');
      }

      if (quantidade <= 0) {
        throw new BadRequestException(
          'Quantidade inválida. Deve ser maior que zero.',
        );
      }

      // 🔴 REGRA DE VALIDAÇÃO MANUAL (ESTOQUE)
      // Para ocorrências manuais, o evento é informativo.
      // A validação deve ser baseada no TIPO da ocorrência:
      if (manual) {
        if (tipo === 'OK') {
          if (quantidade > equipment.quantidadeEmUso) {
            throw new BadRequestException(
              `A quantidade informada (${quantidade}) excede o saldo em uso do equipamento (${equipment.quantidadeEmUso}).`,
            );
          }
        } else {
          // DANO ou PERDA
          if (quantidade > equipment.quantidadeDisponivel) {
            throw new BadRequestException(
              `A quantidade informada (${quantidade}) excede o saldo disponível do equipamento (${equipment.quantidadeDisponivel}).`,
            );
          }
        }
      }

      // 🔴 REGRA UNIFICADA: Manual NÃO altera estoque na criação.
      // Toda mutação acontece via confirmarBaixa().
      // Isso evita bit-rot e dupla mutação.
      // Manual OK: doesn't make much sense manually from scratch in registrar(), 
      // but if allowed, will only change stock on confirm.

      const occurrence = manager.create(EquipmentOccurrence, {
        equipment,
        quantidade,
        descricao,
        tipo,
        status: 'PENDENTE',
        checklistItemId: checklistItemId ?? null,
        ...(event ? { event } : {}),
      });

      const saved = await manager.save(EquipmentOccurrence, occurrence);

      // Auto-sync checklist if linked
      if (checklistItemId) {
        await this.syncChecklistItemFromOccurrences(manager, checklistItemId);
      }

      return saved;
    });
  }

  /**
   * Registrar ocorrência dentro de uma transação existente (para uso pelo checklist-item service).
   */
  async registrarTx(
    manager: EntityManager,
    eventId: number | null,
    equipmentId: number,
    quantidade: number,
    descricao: string,
    tipo: 'DANO' | 'PERDA',
    motivo: string,
    checklistItemId: number | null,
  ): Promise<EquipmentOccurrence> {
    const equipment = await manager.findOne(Equipment, {
      where: { id: equipmentId },
    });

    if (!equipment)
      throw new BadRequestException('Equipamento não encontrado.');

    let event: Event | null = null;
    if (eventId) {
      event = await manager.findOne(Event, { where: { id: eventId } });
    }

    const occurrence = manager.create(EquipmentOccurrence, {
      equipment,
      quantidade,
      descricao,
      tipo,
      motivo,
      status: 'PENDENTE',
      checklistItemId,
      ...(event ? { event } : {}),
    });

    return manager.save(EquipmentOccurrence, occurrence);
  }

  // ============================================================
  // CONFIRMAR BAIXA — ONLY place where DANO/PERDA stock changes happen
  // ============================================================
  /**
   * CONFIRMAR BAIXA: Efetua a alteração de estoque para DANO/PERDA/OK.
   *
   * DANO: emUso (ou disponivel) -= qty, danificada += qty
   * PERDA: emUso (ou disponivel) -= qty, perdida += qty, total -= qty
   * OK: emUso -= qty, disponivel += qty
   *
   * Após confirmar, sincroniza o checklist item automaticamente.
   */
  async confirmarBaixa(id: number) {
    return this.dataSource.transaction(async (manager) => {
      const occurrence = await manager.findOne(EquipmentOccurrence, {
        where: { id },
        relations: ['equipment'],
      });

      if (!occurrence)
        throw new BadRequestException('Ocorrência não encontrada.');

      if (occurrence.status !== 'PENDENTE') {
        throw new BadRequestException('Ocorrência já foi processada.');
      }

      const { tipo, quantidade, equipment } = occurrence;
      const isChecklist = !!occurrence.checklistItemId;

      // Sempre recarrega com lock para garantir integridade
      const eq = await manager.findOne(Equipment, {
        where: { id: equipment.id },
        lock: { mode: 'pessimistic_write' },
      });

      if (!eq) throw new BadRequestException('Equipamento não encontrado.');

      if (tipo === 'DANO') {
        if (isChecklist) {
          await this.stockService.registrarDevolucaoDanificado(
            manager,
            eq.id,
            quantidade,
          );
        } else {
          await this.stockService.registrarDanoManual(
            manager,
            eq.id,
            quantidade,
          );
        }
      } else if (tipo === 'PERDA') {
        if (isChecklist) {
          await this.stockService.registrarDevolucaoPerdido(
            manager,
            eq.id,
            quantidade,
          );
        } else {
          await this.stockService.registrarPerdaManual(
            manager,
            eq.id,
            quantidade,
          );
        }
      } else if (tipo === 'OK') {
        if (eq.quantidadeEmUso >= quantidade) {
          await this.stockService.registrarDevolucaoOk(
            manager,
            eq.id,
            quantidade,
          );
        }
      }

      occurrence.status = 'BAIXADO';
      const saved = await manager.save(EquipmentOccurrence, occurrence);

      // Auto-sync linked checklist item
      if (occurrence.checklistItemId) {
        await this.syncChecklistItemFromOccurrences(
          manager,
          occurrence.checklistItemId,
        );
      }

      return saved;
    });
  }

  // ============================================================
  // CANCELAR — Reverts stock (Manual only)
  // ============================================================
  async cancelar(id: number) {
    return this.dataSource.transaction(async (manager) => {
      const occurrence = await manager.findOne(EquipmentOccurrence, {
        where: { id },
        relations: ['equipment'],
      });

      if (!occurrence)
        throw new BadRequestException('Ocorrência não encontrada.');

      if (occurrence.checklistItemId) {
        throw new BadRequestException(
          'Não é possível cancelar uma ocorrência vinculada a um checklist.',
        );
      }

      if (occurrence.status !== 'PENDENTE') {
        throw new BadRequestException(
          'Apenas ocorrências pendentes podem ser canceladas.',
        );
      }

      await this.reverterImpactoEstoque(manager, occurrence);
      occurrence.status = 'CANCELADO';

      return manager.save(EquipmentOccurrence, occurrence);
    });
  }

  // ============================================================
  // CANCELAR — Reverts stock and syncs checklist
  // ============================================================


  // ============================================================
  // EDITAR — Edição completa de ocorrência com reversão de estoque
  // ============================================================
  /**
   * EDITAR OCORRÊNCIA: Felipe pode alterar quantidade, descrição, tipo e equipamento.
   * Somente ocorrências PENDENTES podem ser editadas.
   *
   * LÓGICA DE REVERSÍO:
   * 1. Reverte o impacto de estoque da ocorrência atual
   * 2. Atualiza os campos da ocorrência
   * 3. Reaplica o impacto de estoque com os novos valores
   * 4. Sincroniza o checklist vinculado (se houver)
   *
   * TUDO dentro de transação — se falhar, rollback completo.
   */
  async editar(
    id: number,
    quantidade?: number,
    descricao?: string,
    tipo?: 'OK' | 'DANO' | 'PERDA',
    equipmentId?: number,
  ) {
    return this.dataSource.transaction(async (manager) => {
      const occurrence = await manager.findOne(EquipmentOccurrence, {
        where: { id },
        relations: ['equipment'],
      });

      if (!occurrence)
        throw new BadRequestException('Ocorrência não encontrada.');

      // Allow editing even if BAIXADO? User request says: "O botão que deve ficar exibindo após as confirmações é o de editar e mais nenhum."
      // So I must allow editing even after confirmation.
      // But if it was already BAIXADO, editing should probably trigger a reversal and re-application if qty/type/equip changes.

      const isChecklist = !!occurrence.checklistItemId;

      // 🔴 REGRA DE NEGÓCIO: O felipe só poderá editar tipo e descrição de ocorrência de checklist
      if (isChecklist) {
        if (quantidade !== undefined && quantidade !== occurrence.quantidade) {
          throw new BadRequestException('Não é possível editar a quantidade de uma ocorrência de checklist.');
        }
        if (equipmentId !== undefined && equipmentId !== occurrence.equipment.id) {
          throw new BadRequestException('Não é possível trocar o equipamento de uma ocorrência de checklist.');
        }
      }

      const mudouQuantidade = quantidade !== undefined && quantidade !== occurrence.quantidade;
      const mudouTipo = tipo !== undefined && tipo !== occurrence.tipo;
      const mudouEquipamento = equipmentId !== undefined && equipmentId !== (occurrence.equipment?.id);

      const precisaReversao = mudouQuantidade || mudouTipo || mudouEquipamento;

      if (precisaReversao) {
        await this.reverterImpactoEstoque(manager, occurrence);

        if (mudouEquipamento) {
          const novoEquipment = await manager.findOne(Equipment, { where: { id: equipmentId } });
          if (!novoEquipment) throw new BadRequestException('Equipamento não encontrado.');
          occurrence.equipment = novoEquipment;
        }

        if (mudouTipo) occurrence.tipo = tipo!;
        if (mudouQuantidade) occurrence.quantidade = quantidade!;

        // 🔴 REGRA UNIFICADA: Se era BAIXADO, volta para PENDENTE para re-confirmação.
        // Se era PENDENTE, apenas atualiza campos (impacto é zero até confirmar).
        if (occurrence.status === 'BAIXADO') {
          occurrence.status = 'PENDENTE';
        }
      }

      if (descricao !== undefined) occurrence.descricao = descricao;

      const saved = await manager.save(EquipmentOccurrence, occurrence);

      if (occurrence.checklistItemId) {
        await this.syncChecklistItemFromOccurrences(manager, occurrence.checklistItemId);
      }

      return saved;
    });
  }

  async findAll(page = 1, limit = 20) {
    const [data, total] = await this.repo.findAndCount({
      order: { createdAt: 'DESC' },
      relations: ['equipment', 'event'],
      skip: (page - 1) * limit,
      take: limit,
    });

    return {
      data,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };
  }
}
