import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { APP_GUARD } from '@nestjs/core';

import { AuthModule } from './auth/auth.module';
import { JwtAuthGuard } from './auth/jwt-auth.guard';
import { RolesGuard } from './auth/roles.guard';

import { UserModule } from './user/user.module';
import { ChecklistModule } from './checklist/checklist.module';
import { ChecklistItemModule } from './checklist-item/checklist-item.module';
import { ChecklistItemHistoryModule } from './checklist-item-history/checklist-item-history.module';
import { EquipmentModule } from './equipment/equipment.module';
import { ChecklistTeamModule } from './checklist-team/checklist-team.module';
import { EventModule } from './event/event.module';
import { EquipmentOccurrenceModule } from './equipment-occurrence/equipment-occurrence.module';
import { AuditLogModule } from './audit-log/audit-log.module';
import { DashboardModule } from './dashboard/dashboard.module';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'localhost',
      port: 5432,
      username: 'postgres',
      password: 'postgres',
      database: 'eventos',
      extra: {
        charset: 'utf8',
        clientEncoding: 'utf8',
        client_encoding: 'UTF8',
      },
      autoLoadEntities: true,
      synchronize: true,
    }),

    AuthModule,
    UserModule,
    ChecklistModule,
    ChecklistItemModule,
    ChecklistItemHistoryModule,
    EquipmentModule,
    ChecklistTeamModule,
    EventModule,
    EquipmentOccurrenceModule,
    AuditLogModule,
    DashboardModule,
  ],
  providers: [
    {
      provide: APP_GUARD,
      useClass: JwtAuthGuard,
    },
    {
      provide: APP_GUARD,
      useClass: RolesGuard,
    },
  ],
})
export class AppModule {}
